package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import module.User;



public class UserDao {

	/**
	 * ��½��֤
	 * @param con
	 * @param user
	 * @return
	 * @throws Exception
	 */
	public User login(Connection con,User user) throws Exception{
		User resultUser = null;
		String sql="select *from user where userName=? and password=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, user.getUid());
		pstmt.setString(2, user.getUpw());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()){
			resultUser = new User();
			resultUser.setUid(rs.getString("uid"));
			resultUser.setUpw(rs.getString("upw"));
		
		}
		return resultUser;
	}
	public int userAdd(Connection con,User user) throws Exception{
		String sql="insert into `user` values(null,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, user.getUid());
		pstmt.setString(2, user.getUpw());
		
		return pstmt.executeUpdate();
	}
	public boolean isUserExist(Connection con,User user) throws Exception{
		String sql="select *from user where userName=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, user.getUid());
		ResultSet rs =pstmt.executeQuery();
		return rs.next();
	}
	
	public int userModify(Connection con,User user) throws Exception{
		String sql="update `user` set userName=?,password=?,email=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, user.getUid());
		pstmt.setString(2, user.getUpw());
		
		return pstmt.executeUpdate();
	}
}
