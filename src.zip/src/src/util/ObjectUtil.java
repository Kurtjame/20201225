package util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ObjectUtil {
    public static String[] getFiledName(Class cls){
        Field[] fields=cls.getDeclaredFields();
        String[] fieldNames=new String[fields.length];
        for(int i=0;i<fields.length;i++){
            fieldNames[i]=fields[i].getName();
        }
        return fieldNames;
    }

    public static Object[][] tran(List<Object> list){
        if(null == list || list.size()==0){
            Object[][] result={{}};
            return  result;
        }
        String[] fieldNames=getFiledName(list.get(0).getClass());
        Object[][] objects=new Object[list.size()][fieldNames.length];

        for (int i = 0; i < list.size(); i++) {
            Object[] objects1=new Object[fieldNames.length];
            for (int i1 = 0; i1 < fieldNames.length; i1++) {
                objects1[i1]=getFieldValueByName(fieldNames[i1],list.get(i));
            }
            objects[i]=objects1;
        }
        return objects;
    }
    private static Object getFieldValueByName(String fieldName, Object o) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(getter, new Class[] {});
            Object value = method.invoke(o, new Object[] {});
            return value;
        } catch (Exception e) {
            return null;
        }
    }
    private static Object setFieldValueByName(String fieldName, Object o,String value) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String setter = "set" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(setter, String.class);
            method.invoke(o, value);
            return o;
        } catch (Exception e) {
            return null;
        }
    }
    public static List<Object> rsToObject(ResultSet rs,Class cls){
        List list=new ArrayList();
        try {

            while(rs.next()){
                Object o=cls.newInstance();
                String[] fields=getFiledName(o.getClass());
                for (String field : fields) {

                    setFieldValueByName(field,o,rs.getString(field));
                }
                list.add(o);
            }
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;

    }
}
