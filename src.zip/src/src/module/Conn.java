package module;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conn {
	private  static Statement stat;
    private  static void init() {
        Connection con;
        String driver="com.mysql.jdbc.Driver"; //JDBC����
        String url="jdbc:mysql://localhost:3306/tonight?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8";
        String user="root";
        String password="123";
       
        try {
            //ע��JDBC��������
            Class.forName(driver);
            //��������
            con = DriverManager.getConnection(url, user, password);
            if (!con.isClosed()) {
                System.out.println("���ݿ����ӳɹ�");
                stat=con.createStatement();
            }
        } catch (ClassNotFoundException e) {
            System.out.println("���ݿ�����ʧ��");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("���ݿ�����ʧ��");
        }
    }

	public static Statement getStat() {
		if(stat==null) init();
		// TODO Auto-generated method stub
		return stat;
	}

	
        
}