
package module;

import com.sun.deploy.util.StringUtils;
import util.ObjectUtil;
import util.StringUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Activity {
	private String actid;
	private String actname;
	private String acttime;
	private String actstyle;
	private String endtime;
	private String limitpeople;
	private String astatus;
	public Activity(){}
	public Activity(String actid,String actname, String acttime, String actstyle,
			String endtime, String limitpeople,String astatus) {
		super();
		this.actname = actname;
		this.acttime = acttime;
		this.actstyle = actstyle;
		this.endtime = endtime;
		this.limitpeople = limitpeople;
	}
	public String getActid() {
		return actid;
	}
	public void setActid(String actid) {
		this.actid = actid;
	}

	public String getActname() {
		return actname;
	}
	public void setActname(String actname) {
		this.actname = actname;
	}
	public String getActtime() {
		return acttime;
	}
	public void setActtime(String acttime) {
		this.acttime = acttime;
	}
	public String getActstyle() {
		return actstyle;
	}
	public void setActstyle(String actstyle) {
		this.actstyle = actstyle;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getLimitpeople() {
		return limitpeople;
	}
	public void setLimitpeople(String limitpeople) {
		this.limitpeople = limitpeople;
	}
	public String getAstatus() {
		return astatus;
	}
	public void setAstatus(String astatus) {
		this.astatus = astatus;
	}
	/**
	 * ���һ
	 * @throws SQLException
	 */
	public static List<Object> selectact(String msg){
		List<Object> activities = new ArrayList();
		String sql = "select * from activity ";
		if(msg !=null && msg !=""){
			sql +="where acttime like '%\"+msg+\"'\"\n" +
					"\t\t\t\t+\" or actname like '%\"+msg+\"'";
		}
		ResultSet rs = null;
		try {
			rs = Conn.getStat().executeQuery(sql);
			activities= ObjectUtil.rsToObject(rs,Activity.class);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return activities;
	}
	public static List<Object> selectactById(String id){
		List<Object> activities = new ArrayList();
		String sql = "select * from activity WHERE actid = " +id;

		ResultSet rs = null;
		try {
			rs = Conn.getStat().executeQuery(sql);
			activities= ObjectUtil.rsToObject(rs,Activity.class);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return activities;
	}
	public boolean insert(Activity activity)throws SQLException{
		String sql = "insert into activity(actname,acttime,actstyle,endtime,limitpeople,astatus)"+
				"values('"+activity.getActname()+"','"
				+activity.getActtime()+"','"
				+activity.getActstyle()+"','"
				+activity.getEndtime()+"','"
				+activity.getLimitpeople()+"','"
				+activity.getAstatus()+"');";
		System.out.println("activity = " + sql);
		int i=Conn.getStat().executeUpdate(sql);
		return i==1;
	}
	public static boolean delete(Activity activity){
		String sql = "delete from  activity where actid = '"+activity.getActid()+"';";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;
	}
	public static boolean update(Activity activity){
		String sql = "update   activity set ";
		List<String> list =new ArrayList();
		if(StringUtil.isNotNull(activity.getActname()) ){
			list.add("actname = '"+activity.getActname()+"\'");
		}
		if(StringUtil.isNotNull(activity.getActtime()) ){
			list.add("acttime = '"+activity.getActtime()+"\'");
		}
		if(StringUtil.isNotNull(activity.getActstyle()) ){
			list.add("actstyle = '"+activity.getActstyle()+"\'");
		}
		if(StringUtil.isNotNull(activity.getEndtime()) ){
			list.add("endtime = '"+activity.getEndtime()+"\'");
		}
		if(StringUtil.isNotNull(activity.getLimitpeople()) ){
			list.add("limitpeople = '"+activity.getLimitpeople()+"\'");
		}
		if(StringUtil.isNotNull(activity.getAstatus()) ){
			list.add("astatus = '"+activity.getAstatus()+"\'");
		}

		sql += StringUtils.join(list, ",");

		sql +=" where actid = '"+activity.getActid()+"';";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;
	}



	

}
