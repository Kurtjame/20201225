package module;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Admin {
	private String aname;
	private int  aid;
	private String apw;
	
	

	

	
	public String getAname() {
		return aname;
	}


	public void setAname(String aname) {
		this.aname = aname;
	}


	public int getAid() {
		return aid;
	}


	public void setAid(int aid) {
		this.aid = aid;
	}


	public String getApw() {
		return apw;
	}


	public void setApw(String apw) {
		this.apw = apw;
	}


	public Admin(String aname, int aid, String apw) {
		super();
		this.aname = aname;
		this.aid = aid;
		this.apw = apw;
	}


	/**
	 * ��¼
	 * @throws SQLException
	 */
	public boolean login(String uname,String upw)throws SQLException {
		String sql = "select * from admin where aname="+uname+" and apw ='"+upw+"'";
		ResultSet rs =  Conn.getStat().executeQuery(sql);
		if(rs.next())
			return true;
		return false;
	}
	
	
	/**
	 * ���ӻ
	 * @throws SQLException
	 */
	public void addact(Activity a)throws SQLException{
		String sql = "insert into activity(actid,actname,acttime,actstyle,endtime,limitpeople)"+
		"values("+a.getActid()+",'"+a.getActname()+",'"+a.getActtime()+",'"+a.getActstyle()+",'"+a.getEndtime()
		+",'"+a.getLimitpeople()+a.getAstatus()+"'";
		Conn.getStat().executeUpdate(sql);
	}
	/**
	 * ɾ���
	 * @throws SQLException
	 */
	public void delectact(String actid)throws SQLException{
		String sql = "delete from activity where actid="+actid;
		Conn.getStat().executeUpdate(sql);
	
	}

	/**
	 * �޸��ѷ����
	 * @throws SQLException
	 */
	public void updact(int actid,String actname,String acttime,String actstyle,String 
			endtime,String limitpeople)throws SQLException{
		
	

	}
	/**
	 * �鿴�
	 * @throws SQLException
	 */
	public Activity viewact(String aid) throws SQLException {
		Activity activities = null;
		String sql = "select * from user where aid="+aid;
		ResultSet rs = Conn.getStat().executeQuery(sql);
		if(rs.next()){
			activities = new Activity(rs.getString(1),rs.getString(2),
					rs.getString(3),rs.getString(4),rs.getString(5),
					rs.getString(6),rs.getString(7));
		}
		return activities;
	}
}