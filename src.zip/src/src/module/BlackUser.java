package module;

import com.sun.deploy.util.StringUtils;
import util.StringUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;


public class BlackUser extends Object {
	private String uid;
	private String uname;
	private String upw;
	private String ugd;
	private String uhobby;
	private String ulct;
	private String ucontact;

	public BlackUser(){
		super();
	}
	public BlackUser(String uid, String uname, String upw, String ugd, String uhobby,
	                 String ulct, String ucontact) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.upw = upw;
		this.ugd = ugd;
		this.uhobby = uhobby;
		this.ulct = ulct;
		this.ucontact = ucontact;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getUgd() {
		return ugd;
	}
	public void setUgd(String ugd) {
		this.ugd = ugd;
	}
	public String getUhobby() {
		return uhobby;
	}
	public void setUhobby(String uhobby) {
		this.uhobby = uhobby;
	}
	public String getUlct() {
		return ulct;
	}
	public void setUlct(String ulct) {
		this.ulct = ulct;
	}
	public String getUcontact() {
		return ucontact;
	}
	public void setUcontact(String ucontact) {
		this.ucontact = ucontact;
	}


	public static boolean add(BlackUser u){
		String sql = "insert into blackuser(uid,uname,upw,ugd,uhobby,ulct,ucontact)"+
		"values("+u.getUid()+",'"+u.getUname()+"','"+u.getUpw()+"','"+u.getUgd()+"','"+u.getUhobby()
		+"','"+u.getUlct()+"','"+u.getUcontact()+"');";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;
	}
	public static List<Object> list( )  {
		List<Object> users = new ArrayList();
		String sql = "select * from blackuser ";
		ResultSet rs = null;
		try {
			rs = Conn.getStat().executeQuery(sql);
			while(rs.next()){
				users.add(new BlackUser(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5),
						rs.getString(6),rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	public static boolean update(BlackUser user)  {
		String sql = "update   blackuser set ";
		List<String> list =new ArrayList();
		if(StringUtil.isNotNull(user.getUname()) ){
			list.add("uname = '"+user.getUname()+"\'");
		}
		if(StringUtil.isNotNull(user.getUpw()) ){
			list.add("upw = '"+user.getUpw()+"\'");
		}
		if(StringUtil.isNotNull(user.getUgd()) ){
			list.add("ugd = '"+user.getUgd()+"\'");
		}
		if(StringUtil.isNotNull(user.getUhobby()) ){
			list.add("uhobby = '"+user.getUhobby()+"\'");
		}
		if(StringUtil.isNotNull(user.getUlct()) ){
			list.add("ulct = '"+user.getUlct()+"\'");
		}
		if(StringUtil.isNotNull(user.getUcontact()) ){
			list.add("ucontact = '"+user.getUcontact()+"\'");
		}


		sql += StringUtils.join(list, ",");

		sql +=" where uid = '"+user.getUid()+"';";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;
	}
	public static boolean dele(BlackUser user){
		String sql = "delete from  blackuser where uid = '"+user.getUid()+"';";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;

	}

}
