package module;

import com.sun.deploy.util.StringUtils;
import util.StringUtil;

import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class User {
	private String uid;
	private String uname;
	private String upw;
	private String ugd;
	private String uhobby;
	private String ulct;
	private String ucontact;

	public User(){
		super();
	}
	public User(String uid, String uname, String upw, String ugd, String uhobby,
			String ulct, String ucontact) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.upw = upw;
		this.ugd = ugd;
		this.uhobby = uhobby;
		this.ulct = ulct;
		this.ucontact = ucontact;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpw() {
		return upw;
	}
	public void setUpw(String upw) {
		this.upw = upw;
	}
	public String getUgd() {
		return ugd;
	}
	public void setUgd(String ugd) {
		this.ugd = ugd;
	}
	public String getUhobby() {
		return uhobby;
	}
	public void setUhobby(String uhobby) {
		this.uhobby = uhobby;
	}
	public String getUlct() {
		return ulct;
	}
	public void setUlct(String ulct) {
		this.ulct = ulct;
	}
	public String getUcontact() {
		return ucontact;
	}
	public void setUcontact(String ucontact) {
		this.ucontact = ucontact;
	}
	
	/**
	 * ��¼
	 * @throws SQLException
	 */
	
	public String login(String uname,String upw) {
		String sql = "select * from user where uname='"+uname+"' and upw ='"+upw+"'";
		ResultSet rs = null;
		try {
			rs = Conn.getStat().executeQuery(sql);
			if(rs.next())
				return rs.getString("uid");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	/**
	 * ע��
	 * @throws SQLException
	 */
	public boolean register(User u)throws SQLException{
		String sql = "insert into user(uid,uname,upw,ugd,uhobby,ulct,ucontact)"+
		"values("+u.getUid()+",'"+u.getUname()+"','"+u.getUpw()+"','"+u.getUgd()+"','"+u.getUhobby()
		+"','"+u.getUlct()+"','"+u.getUcontact()+"');";
		int i=Conn.getStat().executeUpdate(sql);
		return i==1;
		
	}
	public static List<Object> list( )  {
		List<Object> users = new ArrayList<Object>();
		String sql = "select * from user ";

		ResultSet rs = null;
		try {
			rs = Conn.getStat().executeQuery(sql);
			while(rs.next()){
				users.add(new User(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5),
						rs.getString(6),rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	public static List<User> listById(String id)  {
		List<User> users = new ArrayList<User>();
		String sql = "select * from user  where uid ='" +id+"';";

		ResultSet rs = null;
		try {
			rs = Conn.getStat().executeQuery(sql);
			while(rs.next()){
				users.add(new User(rs.getString(1),rs.getString(2),
						rs.getString(3),rs.getString(4),rs.getString(5),
						rs.getString(6),rs.getString(7)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	public static boolean update(User user)  {
		String sql = "update   user  set ";
		List<String> list =new ArrayList();
		if(StringUtil.isNotNull(user.getUname()) ){
			list.add("uname = '"+user.getUname()+"\'");
		}
		if(StringUtil.isNotNull(user.getUpw()) ){
			list.add("upw = '"+user.getUpw()+"\'");
		}
		if(StringUtil.isNotNull(user.getUgd()) ){
			list.add("ugd = '"+user.getUgd()+"\'");
		}
		if(StringUtil.isNotNull(user.getUhobby()) ){
			list.add("uhobby = '"+user.getUhobby()+"\'");
		}
		if(StringUtil.isNotNull(user.getUlct()) ){
			list.add("ulct = '"+user.getUlct()+"\'");
		}
		if(StringUtil.isNotNull(user.getUcontact()) ){
			list.add("ucontact = '"+user.getUcontact()+"\'");
		}


		sql += StringUtils.join(list, ",");

		sql +=" where uid = '"+user.getUid()+"';";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;
	}
	public static boolean dele(User user){
		String sql = "delete from  user where uid = '"+user.getUid()+"';";
		int i= 0;
		try {
			i = Conn.getStat().executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i==1;

	}
	

		
	
}
