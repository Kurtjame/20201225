/*
 * ע��
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import module.User;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

import javax.swing.*;
import java.sql.SQLException;

/**
 *
 * @author  __USER__
 */
public class Register extends JFrame {

	/** Creates new form Register */
	public Register() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">

	private void initComponents() {

		jLabel2 = new JLabel();
		jPasswordField1 = new JPasswordField();
		jButton1 = new JButton();
		jLabel3 = new JLabel();
		jButton2 = new JButton();
		jLabel4 = new JLabel();
		jLabel5 = new JLabel();
		jPasswordField2 = new JPasswordField();
		jLabel6 = new JLabel();

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);


		jPanel1 = new JPanel();
		jPanel1.setBackground(new java.awt.Color(0, 204, 204));
		jPanel1.setLayout(new AbsoluteLayout());
		jLabel1 = new JLabel();
		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel1.setText("ע���˺ţ�");
		jPanel1.add(jLabel1, new AbsoluteConstraints(
				200, 240, -1, -1));

		jTextField1 = new JTextField();
		jTextField1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});
		jPanel1.add(jTextField1,
				new AbsoluteConstraints(390, 240,
						500, 50));




		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel2.setText("\u786e\u8ba4\u5bc6\u7801\uff1a");
		jPanel1.add(jLabel2, new AbsoluteConstraints(
				200, 380, -1, -1));

		jPasswordField1.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jPasswordField1,
				new AbsoluteConstraints(390, 380,
						500, 50));












		jButton1.setBackground(new java.awt.Color(255, 204, 51));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton1.setText("\u6ce8\u518c");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton1,
				new AbsoluteConstraints(390, 450,
						500, 50));

		jLabel3.setFont(new java.awt.Font("Microsoft JhengHei UI", 1, 18));
		jLabel3.setForeground(new java.awt.Color(255, 204, 0));
		jLabel3.setText("\u5df2\u6709\u8d26\u53f7\uff1f");
		jPanel1.add(jLabel3, new AbsoluteConstraints(
				760, 520, -1, -1));

		jButton2.setBackground(new java.awt.Color(0, 204, 204));
		jButton2.setFont(new java.awt.Font("Microsoft JhengHei UI", 1, 18));
		jButton2.setForeground(new java.awt.Color(255, 204, 0));
		jButton2.setText("\u767b\u5f55");
		jButton2.setBorder(null);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton2,
				new AbsoluteConstraints(850, 520, -1,
						-1));

		jLabel4.setFont(new java.awt.Font("����", 1, 72));
		jLabel4.setText("\u6ce8\u518c\u5bc2\u5bde\u5c31\u6765");
		jPanel1.add(jLabel4, new AbsoluteConstraints(
				200, 100, -1, -1));

		jLabel5.setFont(new java.awt.Font("����", 1, 72));
		jLabel5.setForeground(new java.awt.Color(255, 204, 0));
		jLabel5.setText("\u5bc2\u5bde\u5c31\u6765");
		jPanel1.add(jLabel5, new AbsoluteConstraints(
				349, 100, -1, -1));

		jPasswordField2.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jPasswordField2,
				new AbsoluteConstraints(390, 310,
						500, 50));

		jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel6.setText("\u8bbe\u7f6e\u5bc6\u7801\uff1a");
		jPanel1.add(jLabel6, new AbsoluteConstraints(
				200, 310, -1, -1));









		jLabel12 = new JLabel();
		jTextField12 = new JTextField();
		jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel12.setText("ulct");
		jPanel1.add(jLabel12, new AbsoluteConstraints(
				200, 590, -1, -1));

		jTextField12.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField12,
				new AbsoluteConstraints(390, 590,
						500, 50));



		jLabel13 = new JLabel();
		jTextField13 = new JTextField();
		jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel13.setText("ucontact");
		jPanel1.add(jLabel13, new AbsoluteConstraints(
				200, 660, -1, -1));

		jTextField13.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField13,
				new AbsoluteConstraints(390, 660,
						500, 50));


		jLabel11 = new JLabel();
		jTextField11 = new JTextField();
		jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel11.setText("uhobby");
		jPanel1.add(jLabel11, new AbsoluteConstraints(
				200, 710, -1, -1));

		jTextField11.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField11,
				new AbsoluteConstraints(390, 710,
						500, 50));



		jLabel14 = new JLabel();
		jTextField14 = new JTextField();
		jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel14.setText("ugd");
		jPanel1.add(jLabel14, new AbsoluteConstraints(
				200, 790, -1, -1));

		jTextField14.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField14,
				new AbsoluteConstraints(390, 790,
						500, 50));








































		GroupLayout layout = new GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, GroupLayout.PREFERRED_SIZE, 1200,
				GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, GroupLayout.PREFERRED_SIZE, 1200,
				GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new Login().setVisible(true);
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		User u=new User();
		u.setUname(this.jTextField1.getText());
		u.setUpw(new String(this.jPasswordField1.getPassword()));
		u.setUgd(this.jTextField11.getText());
		u.setUhobby(this.jTextField12.getText());
		u.setUlct(this.jTextField13.getText());
		u.setUcontact(this.jTextField14.getText());
		try {
			boolean b=u.register(u);
			if(b){
				JOptionPane.showMessageDialog(null, "ע��ɹ�");
			}else {
				JOptionPane.showMessageDialog(null, "ע��ʧ��");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.dispose();
		new Login().setVisible(true);
	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Register().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private JTextField jTextField1;
	private JLabel jLabel1;
	private JPanel jPanel1;



	private JButton jButton1;
	private JButton jButton2;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JLabel jLabel6;
	private JPasswordField jPasswordField1;
	private JPasswordField jPasswordField2;

	private JLabel jLabel11;
	private JTextField jTextField11;

	private JLabel jLabel12;
	private JTextField jTextField12;
	private JLabel jLabel13;
	private JTextField jTextField13;
	private JLabel jLabel14;
	private JTextField jTextField14;

	// End of variables declaration//GEN-END:variables

}