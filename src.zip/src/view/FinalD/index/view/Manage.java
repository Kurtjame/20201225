/*
 * Manage.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import module.User;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.util.List;

/**
 * @author __USER__
 */
public class Manage extends JFrame {

    /**
     * Creates new form Manage
     */
    public Manage() {
        this.id="";
        initComponents();
        this.setLocationRelativeTo(null);
    }
    public Manage(String id) {
        this.id=id;
        initComponents();
        this.setLocationRelativeTo(null);
    }

    //GEN-BEGIN:initComponents
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    private void initComponents() {
        User user=new User();
        if(!"999".equals(this.id) ){
            List list=User.listById(this.id);
            user= (User) list.get(0);
        }

        jPanel2 = new JPanel();

        jButton9 = new JButton();
        jScrollPane1 = new JScrollPane();
        jPanel1 = new JPanel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jLabel3 = new JLabel();
        jLabel6 = new JLabel();
        jLabel8 = new JLabel();
        jLabel7 = new JLabel();
        jButton8 = new JButton();
        jLabel9 = new JLabel();
        jLabel10 = new JLabel();
        jLabel12 = new JLabel();
        jLabel14 = new JLabel();
        jComboBox3 = new JComboBox();
        jLabel13 = new JLabel();
        jComboBox2 = new JComboBox();
        jLabel11 = new JLabel();
        jComboBox1 = new JComboBox();
        jComboBox4 = new JComboBox();
        jTextField1 = new JTextField();
        jTextField2 = new JTextField();
        jTextField3 = new JTextField();
        jTextField4 = new JTextField();
        jTextField5 = new JTextField();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(
                new AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 204, 102));
        jPanel2.setLayout(new AbsoluteLayout());


        jButton9.setBackground(new java.awt.Color(0, 204, 204));
        jButton9.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24));
        jButton9.setForeground(new java.awt.Color(255, 204, 0));
        jButton9.setText("<back");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9,
                new AbsoluteConstraints(0, 20, 170,
                        50));



        getContentPane().add(
                jPanel2,
                new AbsoluteConstraints(0, 0, 170,
                        600));

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setLayout(new AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 28));
        jLabel4.setForeground(new java.awt.Color(255, 204, 0));
        jLabel4.setText("\u4e2a\u4eba\u4fe1\u606f");
        jPanel1.add(jLabel4, new AbsoluteConstraints(
                90, 30, -1, -1));

        jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel5.setText("��ʵ������");
        jPanel1.add(jLabel5, new AbsoluteConstraints(
                120, 80, 100, 30));

        jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel3.setText("\u6027       \u522b\uff1a");
        jPanel1.add(jLabel3, new AbsoluteConstraints(
                120, 120, -1, 30));

        jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel6.setText("��       �գ�");
        jPanel1.add(jLabel6, new AbsoluteConstraints(
                120, 160, 100, 30));

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel8.setText("��Ȥ���ã�");
        jPanel1.add(jLabel8, new AbsoluteConstraints(
                120, 200, 100, 30));

        jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel7.setText("��ϵ��ʽ��");
        jPanel1.add(jLabel7, new AbsoluteConstraints(
                120, 240, 100, 30));

        jButton8.setBackground(new java.awt.Color(255, 204, 0));
        jButton8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jButton8.setText("������Ϣ");
        jButton8.setBorder(BorderFactory
                .createLineBorder(new java.awt.Color(255, 255, 255)));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8,
                new AbsoluteConstraints(720, 500,
                        200, 50));

        jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel9.setText("���ڵ�����");
        jPanel1.add(jLabel9, new AbsoluteConstraints(
                120, 280, 100, 30));

        jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel10.setText("����˵����");
        jPanel1.add(jLabel10,
                new AbsoluteConstraints(120, 320,
                        100, 30));

        jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel12.setText("�����ȼ���");
        jPanel1.add(jLabel12,
                new AbsoluteConstraints(120, 400,
                        100, 30));

        jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel14.setText("\u65e5");
        jPanel1.add(jLabel14,
                new AbsoluteConstraints(480, 160, -1,
                        -1));

        jComboBox3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jComboBox3.setModel(new DefaultComboBoxModel(new String[]{
                "Item 1", "Item 2", "Item 3", "Item 4"}));
        jComboBox3.setEnabled(false);
        jPanel1.add(jComboBox3,
                new AbsoluteConstraints(420, 160, -1,
                        -1));

        jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel13.setText("\u6708");
        jPanel1.add(jLabel13,
                new AbsoluteConstraints(390, 160, -1,
                        -1));

        jComboBox2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jComboBox2.setModel(new DefaultComboBoxModel(new String[]{
                "Item 1", "Item 2", "Item 3", "Item 4"}));
        jComboBox2.setEnabled(false);
        jPanel1.add(jComboBox2,
                new AbsoluteConstraints(330, 160, -1,
                        30));

        jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jLabel11.setText("\u5e74");
        jPanel1.add(jLabel11,
                new AbsoluteConstraints(300, 160, -1,
                        -1));

        jComboBox1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jComboBox1.setModel(new DefaultComboBoxModel(new String[]{
                "Item 1", "Item 2", "Item 3", "Item 4"}));
        jComboBox1.setEnabled(false);
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox1,
                new AbsoluteConstraints(220, 160, -1,
                        30));

        jComboBox4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jComboBox4.setModel(new DefaultComboBoxModel(new String[]{
                "��", "Ů"}));
        jComboBox4.setEnabled(false);
        jPanel1.add(jComboBox4,
                new AbsoluteConstraints(220, 120, 90,
                        -1));

        jTextField1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        //��ʵ����
        jTextField1.setText(user.getUname());
        jTextField1.setEnabled(false);
        jPanel1.add(jTextField1,
                new AbsoluteConstraints(220, 80, 100,
                        30));

        jTextField2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jTextField2.setText(user.getUhobby());
        jTextField2.setEnabled(false);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2,
                new AbsoluteConstraints(220, 200,
                        700, 30));

        jTextField3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        //���ڵ���
        jTextField3.setText(user.getUlct());
        jTextField3.setEnabled(false);

        jPanel1.add(jTextField3,
                new AbsoluteConstraints(220, 280,
                        700, 30));

        jTextField4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jTextField4.setEnabled(false);
        jPanel1.add(jTextField4,
                new AbsoluteConstraints(220, 240,
                        700, 30));

        jTextField5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
        jTextField5.setText(user.getUcontact());
        jTextField5.setEnabled(false);
        //����˵��
        jPanel1.add(jTextField5,
                new AbsoluteConstraints(220, 320,
                        700, 60));

        jScrollPane1.setViewportView(jPanel1);

        getContentPane().add(
                jScrollPane1,
                new AbsoluteConstraints(170, 0, 1030,
                        600));

        pack();
    }// </editor-fold>
    //GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
        new Blacklist().setVisible(true);
    }

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
        new Managing(this.id).setVisible(true);
    }

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
        this.dispose();
    }

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
        new Relese().setVisible(true);
    }

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
        new Manage().setVisible(true);
    }

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
        new Order().setVisible(true);
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        new MyRelese().setVisible(true);
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        new Index().setVisible(true);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Manage().setVisible(true);
            }
        });
    }

    //GEN-BEGIN:variables
    // Variables declaration - do not modify

    private JButton jButton8;
    private JButton jButton9;
    private JComboBox jComboBox1;
    private JComboBox jComboBox2;
    private JComboBox jComboBox3;
    private JComboBox jComboBox4;
    private JLabel jLabel10;
    private JLabel jLabel11;
    private JLabel jLabel12;
    private JLabel jLabel13;
    private JLabel jLabel14;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    private JPanel jPanel1;
    private JPanel jPanel2;
    private JScrollPane jScrollPane1;
    private JTextField jTextField1;
    private JTextField jTextField2;
    private JTextField jTextField3;
    private JTextField jTextField4;
    private JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
    private String id;

}