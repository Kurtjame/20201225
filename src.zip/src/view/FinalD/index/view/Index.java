/*
 * Index.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import module.Activity;
import org.netbeans.lib.awtextra.AbsoluteLayout;

import org.netbeans.lib.awtextra.AbsoluteConstraints;
import util.ObjectUtil;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author  __USER__
 */
public class Index extends JFrame {

	/** Creates new form Index */
	public Index() {
		initComponents();
		this.setLocationRelativeTo(null);
	}
	public Index(String id) {
		this.id=id;
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel2 = new JPanel();
		jButton1 = new JButton();
		jButton3 = new JButton();
		jButton4 = new JButton();
		jButton5 = new JButton();
		jButton6 = new JButton();
		jButton10 = new JButton();
		jButton11 = new JButton();
		jButton12 = new JButton();
		jButton9 = new JButton();
		jScrollPane1 = new JScrollPane();
		jPanel1 = new JPanel();
		jLabel3 = new JLabel();
		jButton7 = new JButton();
		jLabel5 = new JLabel();
		jButton8 = new JButton();
		jTextField2 = new JTextField();
		jScrollPane2 = new JScrollPane();
		jTable1 = new JTable();

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);
		getContentPane().setLayout(
				new AbsoluteLayout());

		jPanel2.setBackground(new java.awt.Color(255, 204, 102));
		jPanel2.setLayout(new AbsoluteLayout());

		jButton1.setBackground(new java.awt.Color(255, 204, 0));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton1.setText("��ҳ");
		jButton1.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jPanel2.add(jButton1,
				new AbsoluteConstraints(0, 90, 170,
						50));


		jButton12.setBackground(new java.awt.Color(255, 204, 0));
		jButton12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton12.setText("�û��б�");
		jButton12.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton12ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton12,
				new AbsoluteConstraints(0, 140, 170,
						50));

		jButton6.setBackground(new java.awt.Color(255, 204, 0));
		jButton6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton6.setText("����");
		jButton6.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton6,
				new AbsoluteConstraints(0, 190, 170,
						50));

		/*jButton3.setBackground(new java.awt.Color(255, 204, 0));
		jButton3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton3.setText("�ҵķ���");
		jButton3.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton3,
				new AbsoluteConstraints(0, 140, 170,
						50));

		jButton4.setBackground(new java.awt.Color(255, 204, 0));
		jButton4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton4.setText("�ҵ�ԤԼ");
		jButton4.setBorder(new LineBorder(
				new java.awt.Color(255, 255, 255), 1, true));
		jButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton4,
				new AbsoluteConstraints(0, 190, 170,
						50));
*/


		if("999".equals(this.id)){
			jButton11.setBackground(new java.awt.Color(255, 204, 0));
			jButton11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
			jButton11.setText("������");
			jButton11.setBorder(BorderFactory
					.createLineBorder(new java.awt.Color(255, 255, 255)));
			jButton11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					jButton11ActionPerformed(evt);
				}
			});
			jPanel2.add(jButton11,
					new AbsoluteConstraints(0, 240, 170,
							50));
		}else{
			jButton5.setBackground(new java.awt.Color(255, 204, 0));
			jButton5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
			jButton5.setText("�˺Ź���");
			jButton5.setBorder(BorderFactory
					.createLineBorder(new java.awt.Color(255, 255, 255)));
			jButton5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent evt) {
					jButton5ActionPerformed(evt);
				}
			});
			jPanel2.add(jButton5,
					new AbsoluteConstraints(0, 240, 170,
							50));
		}


		jButton10.setBackground(new java.awt.Color(0, 204, 204));
		jButton10.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24));
		jButton10.setForeground(new java.awt.Color(255, 204, 0));
		jButton10.setText("<back");
		jButton10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton10ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton10,
				new AbsoluteConstraints(0, 20, 170,
						50));




		jButton9.setBackground(new java.awt.Color(0, 204, 204));
		jButton9.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24));
		jButton9.setForeground(new java.awt.Color(255, 204, 0));
		jButton9.setText("�˳���¼");
		jButton9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton9,
				new AbsoluteConstraints(0, 530, 170,
						50));

		getContentPane().add(
				jPanel2,
				new AbsoluteConstraints(0, 0, 170,
						600));

		jPanel1.setBackground(new java.awt.Color(0, 204, 204));
		jPanel1.setLayout(new AbsoluteLayout());

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel3.setText("\u6d3b\u52a8\u540d\u79f0");
		jPanel1.add(jLabel3, new AbsoluteConstraints(
				130, 130, 500, 30));

		jButton7.setBackground(new java.awt.Color(255, 204, 0));
		jButton7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton7.setText("�鿴����");
		jButton7.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton7,
				new AbsoluteConstraints(810, 470,
						120, 30));

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel5.setText("�����");
		jPanel1.add(jLabel5, new AbsoluteConstraints(
				80, 830, 500, 30));

		jButton8.setBackground(new java.awt.Color(255, 204, 0));
		jButton8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton8.setText("\u67e5\u770b\u8be6\u60c5");
		jButton8.setBorder(BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton8,
				new AbsoluteConstraints(810, 830,
						120, 30));

		jTextField2.setBackground(new java.awt.Color(0, 204, 204));
		jTextField2.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 36));
		jTextField2.setForeground(new java.awt.Color(255, 204, 0));
		jTextField2.setText("\u9996\u9875");
		jTextField2.setBorder(null);
		jPanel1.add(jTextField2,
				new AbsoluteConstraints(90, 50, -1,
						-1));

		jTable1.setModel(new DefaultTableModel(
				ObjectUtil.tran(Activity.selectact("")), ObjectUtil.getFiledName(Activity.class)));
		jScrollPane2.setViewportView(jTable1);

		jPanel1.add(jScrollPane2,
				new AbsoluteConstraints(130, 180,
						740, 280));

		jScrollPane1.setViewportView(jPanel1);

		getContentPane().add(
				jScrollPane1,
				new AbsoluteConstraints(170, 0, 1030,
						600));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton11ActionPerformed(ActionEvent evt) {
		new Blacklist().setVisible(true);
	}
	private void jButton12ActionPerformed(ActionEvent evt) {
		new Userlist(this.id).setVisible(true);
	}

	private void jButton10ActionPerformed(ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton9ActionPerformed(ActionEvent evt) {
		new Login().setVisible(true);
	}

	private void jButton8ActionPerformed(ActionEvent evt) {
		new Details().setVisible(true);
	}

	private void jButton7ActionPerformed(ActionEvent evt) {
		int i=jTable1.getSelectedRow();
		String id="";
		if(i>-1){
			id=jTable1.getValueAt(i,0).toString();

		}
		new Details(id).setVisible(true);
	}

	private void jButton6ActionPerformed(ActionEvent evt) {
		new Relese().setVisible(true);
	}

	private void jButton5ActionPerformed(ActionEvent evt) {
		new Manage(this.id).setVisible(true);
	}

	private void jButton4ActionPerformed(ActionEvent evt) {
		new Order().setVisible(true);
	}

	void jButton3ActionPerformed(ActionEvent evt) {
		new MyRelese().setVisible(true);
	}

	private void jButton2Actiold1ActionPerformed(ActionEvent evt) {
		// TODO add your handling code here:
	}

	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Index().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private JButton jButton1;
	private JButton jButton10;
	private JButton jButton11;
	private JButton jButton12;
	private JButton jButton3;
	private JButton jButton4;
	private JButton jButton5;
	private JButton jButton6;
	private JButton jButton7;
	private JButton jButton8;
	private JButton jButton9;
	private JLabel jLabel3;
	private JLabel jLabel5;
	private JPanel jPanel1;
	private JPanel jPanel2;
	private JScrollPane jScrollPane1;
	private JScrollPane jScrollPane2;
	private JTable jTable1;
	private JTextField jTextField2;
	private String id;
	// End of variables declaration//GEN-END:variables

}