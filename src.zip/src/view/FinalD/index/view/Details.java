/*
 * Details.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;


import module.Activity;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;
import util.ObjectUtil;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author  __USER__
 */
public class Details extends JFrame {

	/** Creates new form Details */
	public Details() {
		id="";
		initComponents();
		this.setLocationRelativeTo(null);
		setDate();
		setNum();
	}
	public Details(String id) {
		this.id=id;
		initComponents();
		this.setLocationRelativeTo(null);
		setDate();
		setNum();
	}

	public void setNum() {
		Object num1[] = new Object[500];
		for (int i = 0; i < 500; i++) {
			num1[i] = i + 1;
		}
		this.jComboBox4.setModel(new DefaultComboBoxModel(num1));
		Object num2[] = new Object[500];
		for (int i = 0; i < 500; i++) {
			num2[i] = i + 1;
		}
		this.jComboBox5.setModel(new DefaultComboBoxModel(num2));
	}

	public void setDate() {
		Object year[] = new Object[100];
		for (int i = 0; i < 100; i++) {
			year[i] = i + 2020;
		}
		this.jComboBox1.setModel(new DefaultComboBoxModel(year));
		Object month[] = new Object[12];
		for (int i = 0; i < 12; i++) {
			month[i] = i + 1;
		}
		this.jComboBox2.setModel(new DefaultComboBoxModel(month));
		Object day[] = new Object[31];
		for (int i = 0; i < 31; i++) {
			day[i] = i + 1;
		}
		this.jComboBox3.setModel(new DefaultComboBoxModel(day));
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		Activity activity=new Activity();
		if(this.id !=""){
			List list=Activity.selectactById(this.id);
			activity= (Activity) list.get(0);
		}



		jPanel2 = new  JPanel();

		jButton10 = new  JButton();
		jScrollPane2 = new  JScrollPane();
		jScrollPane1 = new  JScrollPane();
		jPanel1 = new  JPanel();
		jLabel2 = new  JLabel();
		jLabel5 = new  JLabel();
		jLabel3 = new  JLabel();
		jLabel6 = new  JLabel();
		jLabel8 = new  JLabel();
		jLabel7 = new  JLabel();
		jTextField3 = new  JTextField();
		jLabel11 = new  JLabel();
		jLabel10 = new  JLabel();
		jComboBox1 = new  JComboBox();
		jComboBox2 = new  JComboBox();
		jComboBox3 = new  JComboBox();
		jLabel9 = new  JLabel();
		jComboBox4 = new  JComboBox();
		jLabel12 = new  JLabel();
		jComboBox5 = new  JComboBox();
		jLabel13 = new  JLabel();
		jTextField2 = new  JTextField();
		jScrollPane3 = new  JScrollPane();
		jTextArea1 = new  JTextArea();
		jScrollPane4 = new  JScrollPane();
		jTextArea2 = new  JTextArea();
		jButton9 = new  JButton();
		jTextField4 = new  JTextField();

		setDefaultCloseOperation( WindowConstants.EXIT_ON_CLOSE);
		setBackground(new  Color(255, 255, 255));
		setResizable(false);
		getContentPane().setLayout(
				new  AbsoluteLayout());

		jPanel2.setBackground(new  Color(255, 204, 102));
		jPanel2.setLayout(new AbsoluteLayout());


		jButton10.setBackground(new  Color(0, 204, 204));
		jButton10.setFont(new  Font("Microsoft YaHei UI", 1, 24));
		jButton10.setForeground(new  Color(255, 204, 0));
		jButton10.setText("<back");
		jButton10.addActionListener(new   ActionListener() {
			public void actionPerformed(  ActionEvent evt) {
				jButton10ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton10,
				new  AbsoluteConstraints(0, 20, 170,
						50));


		getContentPane().add(
				jPanel2,
				new  AbsoluteConstraints(0, 0, 170,
						600));

		jScrollPane1.setBackground(new  Color(255, 255, 255));

		jPanel1.setBackground(new  Color(0, 204, 204));
		jPanel1.setEnabled(false);
		jPanel1.setLayout(new  AbsoluteLayout());

		jLabel2.setText("ͼƬ");
		jLabel2.setBorder( BorderFactory
				.createLineBorder(new  Color(0, 0, 0)));
		jPanel1.add(jLabel2, new  AbsoluteConstraints(
				110, 170, 800, 270));

		jLabel5.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel5.setText("����ܣ�");
		jPanel1.add(jLabel5, new  AbsoluteConstraints(
				110, 460, 100, 30));

		jLabel3.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel3.setText("�ʱ�䣺");
		jPanel1.add(jLabel3, new  AbsoluteConstraints(
				110, 610, 100, 30));

		jLabel6.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel6.setText("��ص㣺");
		jPanel1.add(jLabel6, new  AbsoluteConstraints(
				110, 650, 100, 30));

		jLabel8.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel8.setText("ע�����");
		jPanel1.add(jLabel8, new  AbsoluteConstraints(
				110, 730, 100, 30));

		jLabel7.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel7.setText("�������");
		jPanel1.add(jLabel7, new  AbsoluteConstraints(
				110, 690, 100, 30));
		//���û�ص�
		jTextField3.setText(activity.getActtime());
		jPanel1.add(jTextField3,
				new  AbsoluteConstraints(200, 650,
						710, 30));

		jLabel11.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel11.setText("\u65e5");
		jPanel1.add(jLabel11,
				new  AbsoluteConstraints(460, 610, -1,
						-1));

		jLabel10.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel10.setText("\u6708");
		jPanel1.add(jLabel10,
				new  AbsoluteConstraints(370, 610, -1,
						-1));

		jComboBox1.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jComboBox1.setModel(new  DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox1.setEnabled(false);
		jComboBox1.addActionListener(new   ActionListener() {
			public void actionPerformed(  ActionEvent evt) {
				jComboBox1ActionPerformed(evt);
			}
		});
		jPanel1.add(jComboBox1,
				new  AbsoluteConstraints(200, 610, -1,
						-1));

		jComboBox2.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jComboBox2.setModel(new  DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox2.setEnabled(false);
		jPanel1.add(jComboBox2,
				new  AbsoluteConstraints(310, 610, -1,
						-1));

		jComboBox3.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jComboBox3.setModel(new  DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox3.setEnabled(false);
		jPanel1.add(jComboBox3,
				new  AbsoluteConstraints(400, 610, -1,
						-1));

		jLabel9.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel9.setText("\u5e74");
		jPanel1.add(jLabel9, new  AbsoluteConstraints(
				280, 610, -1, -1));

		jComboBox4.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jComboBox4.setModel(new  DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox4.setEnabled(false);
		jPanel1.add(jComboBox4,
				new  AbsoluteConstraints(200, 690, -1,
						-1));

		jLabel12.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel12.setText("\u4eba~");
		jPanel1.add(jLabel12,
				new  AbsoluteConstraints(280, 690, -1,
						-1));

		jComboBox5.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jComboBox5.setModel(new  DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox5.setEnabled(false);
		jPanel1.add(jComboBox5,
				new  AbsoluteConstraints(320, 690, -1,
						-1));

		jLabel13.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jLabel13.setText("\u4eba");
		jPanel1.add(jLabel13,
				new  AbsoluteConstraints(400, 690, -1,
						-1));

		jTextField2.setBackground(new  Color(0, 204, 204));
		jTextField2.setFont(new  Font("Microsoft YaHei UI", 1, 36));
		jTextField2.setForeground(new  Color(255, 204, 0));
		jTextField2.setText("�����");
		jTextField2.setBorder(null);
		jPanel1.add(jTextField2,
				new  AbsoluteConstraints(90, 50, -1,
						-1));

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		//���û����
		jTextArea1.setText(activity.getActname());

		jScrollPane3.setViewportView(jTextArea1);

		jPanel1.add(jScrollPane3,
				new  AbsoluteConstraints(200, 460,
						710, 140));

		jTextArea2.setColumns(20);
		jTextArea2.setRows(5);
		//����ע������
		jTextArea2.setText(activity.getActstyle());
		jScrollPane4.setViewportView(jTextArea2);

		jPanel1.add(jScrollPane4,
				new  AbsoluteConstraints(200, 730,
						710, 110));

		jButton9.setBackground(new  Color(255, 204, 0));
		jButton9.setFont(new  Font("Microsoft YaHei UI", 0, 18));
		jButton9.setText("���ԤԼ");
		jButton9.setBorder( BorderFactory
				.createLineBorder(new  Color(255, 255, 255)));
		jButton9.addActionListener(new   ActionListener() {
			public void actionPerformed(  ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton9,
				new  AbsoluteConstraints(810, 860,
						100, 50));

		jTextField4.setBackground(new  Color(0, 204, 204));
		jTextField4.setFont(new  Font("Microsoft YaHei UI", 1, 24));
		jTextField4.setForeground(new  Color(255, 204, 0));
		jTextField4.setText("�����");
		jTextField4.setBorder(null);
		jPanel1.add(jTextField4,
				new  AbsoluteConstraints(110, 130, -1,
						-1));

		jScrollPane1.setViewportView(jPanel1);

		jScrollPane2.setViewportView(jScrollPane1);

		getContentPane().add(
				jScrollPane2,
				new  AbsoluteConstraints(170, 0, 1030,
						600));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton7ActionPerformed(  ActionEvent evt) {
		new Blacklist().setVisible(true);
	}

	private void jButton9ActionPerformed(  ActionEvent evt) {
		int n = JOptionPane.showConfirmDialog(null, "�Ƿ�ԤԼ?", "��ʾ",
				JOptionPane.YES_NO_OPTION);
		if (n == 0) {
			JOptionPane.showMessageDialog(null, "ԤԼ�ɹ�");
			new Order().setVisible(true);
		} else {
			new Details().setVisible(true);
		}
	}

	private void jComboBox1ActionPerformed(  ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton10ActionPerformed(  ActionEvent evt) {
		this.dispose();
	}

	private void jButton6ActionPerformed(  ActionEvent evt) {
		new Relese().setVisible(true);
	}

	private void jButton5ActionPerformed(  ActionEvent evt) {
		new Manage().setVisible(true);
	}

	private void jButton4ActionPerformed(  ActionEvent evt) {
		new Order().setVisible(true);
	}

	private void jButton3ActionPerformed(  ActionEvent evt) {
		new MyRelese().setVisible(true);
	}

	private void jButton1ActionPerformed(  ActionEvent evt) {
		new Index().setVisible(true);
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		 EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Details().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify

	private  JButton jButton10;

	private  JButton jButton9;
	private  JComboBox jComboBox1;
	private  JComboBox jComboBox2;
	private  JComboBox jComboBox3;
	private  JComboBox jComboBox4;
	private  JComboBox jComboBox5;
	private  JLabel jLabel10;
	private  JLabel jLabel11;
	private  JLabel jLabel12;
	private  JLabel jLabel13;
	private  JLabel jLabel2;
	private  JLabel jLabel3;
	private  JLabel jLabel5;
	private  JLabel jLabel6;
	private  JLabel jLabel7;
	private  JLabel jLabel8;
	private  JLabel jLabel9;
	private  JPanel jPanel1;
	private  JPanel jPanel2;
	private  JScrollPane jScrollPane1;
	private  JScrollPane jScrollPane2;
	private  JScrollPane jScrollPane3;
	private  JScrollPane jScrollPane4;
	private  JTextArea jTextArea1;
	private  JTextArea jTextArea2;
	private  JTextField jTextField2;
	private  JTextField jTextField3;
	private  JTextField jTextField4;
	private String id;
	// End of variables declaration//GEN-END:variables

}