/*
 * Relese.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 *
 * @author  __USER__
 */
public class Edit extends javax.swing.JFrame {

	/** Creates new form Relese */
	public Edit() {
		initComponents();
		this.setLocationRelativeTo(null);
		setNum();
		setDate();
	}

	public void setNum() {
		Object num1[] = new Object[500];
		for (int i = 0; i < 500; i++) {
			num1[i] = i + 1;
		}
		this.jComboBox4.setModel(new DefaultComboBoxModel(num1));
		Object num2[] = new Object[500];
		for (int i = 0; i < 500; i++) {
			num2[i] = i + 1;
		}
		this.jComboBox5.setModel(new DefaultComboBoxModel(num2));
	}

	public void setDate() {
		Object year[] = new Object[100];
		for (int i = 0; i < 100; i++) {
			year[i] = i + 2020;
		}
		this.jComboBox1.setModel(new DefaultComboBoxModel(year));
		Object month[] = new Object[12];
		for (int i = 0; i < 12; i++) {
			month[i] = i + 1;
		}
		this.jComboBox2.setModel(new DefaultComboBoxModel(month));
		Object day[] = new Object[31];
		for (int i = 0; i < 31; i++) {
			day[i] = i + 1;
		}
		this.jComboBox3.setModel(new DefaultComboBoxModel(day));
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel2 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jButton4 = new javax.swing.JButton();
		jButton5 = new javax.swing.JButton();
		jButton6 = new javax.swing.JButton();
		jButton9 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jScrollPane3 = new javax.swing.JScrollPane();
		jPanel1 = new javax.swing.JPanel();
		jLabel2 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jLabel11 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();
		jComboBox1 = new javax.swing.JComboBox();
		jComboBox2 = new javax.swing.JComboBox();
		jComboBox3 = new javax.swing.JComboBox();
		jLabel9 = new javax.swing.JLabel();
		jComboBox4 = new javax.swing.JComboBox();
		jLabel12 = new javax.swing.JLabel();
		jComboBox5 = new javax.swing.JComboBox();
		jLabel13 = new javax.swing.JLabel();
		jTextField2 = new javax.swing.JTextField();
		jScrollPane4 = new javax.swing.JScrollPane();
		jTextArea1 = new javax.swing.JTextArea();
		jScrollPane5 = new javax.swing.JScrollPane();
		jTextArea2 = new javax.swing.JTextArea();
		jButton10 = new javax.swing.JButton();
		jTextField4 = new javax.swing.JTextField();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);
		getContentPane().setLayout(
				new org.netbeans.lib.awtextra.AbsoluteLayout());

		jPanel2.setBackground(new java.awt.Color(255, 204, 102));
		jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

		jButton1.setBackground(new java.awt.Color(255, 204, 0));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton1.setText("\u9996\u9875");
		jButton1.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton1,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 170,
						50));

		jButton3.setBackground(new java.awt.Color(255, 204, 0));
		jButton3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton3.setText("\u6211\u7684\u53d1\u5e03");
		jButton3.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton3ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton3,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 170,
						50));

		jButton4.setBackground(new java.awt.Color(255, 204, 0));
		jButton4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton4.setText("\u6211\u7684\u9884\u7ea6");
		jButton4.setBorder(new javax.swing.border.LineBorder(
				new java.awt.Color(255, 255, 255), 1, true));

		jPanel2.add(jButton4,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 170,
						50));

		jButton5.setBackground(new java.awt.Color(255, 204, 0));
		jButton5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton5.setText("\u8d26\u53f7\u7ba1\u7406");
		jButton5.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));

		jPanel2.add(jButton5,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 170,
						50));

		jButton6.setBackground(new java.awt.Color(255, 204, 0));
		jButton6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton6.setText("\u53d1\u8d77\u6d3b\u52a8");
		jButton6.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton6.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton6ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton6,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 170,
						50));

		jButton9.setBackground(new java.awt.Color(0, 204, 204));
		jButton9.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24));
		jButton9.setForeground(new java.awt.Color(255, 204, 0));
		jButton9.setText("<back");
		jButton9.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton9,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 170,
						50));

		jButton7.setBackground(new java.awt.Color(255, 204, 0));
		jButton7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton7.setText("\u9ed1\u540d\u5355");
		jButton7.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton7.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton7ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton7,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 170,
						50));

		getContentPane().add(
				jPanel2,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170,
						600));

		jPanel1.setBackground(new java.awt.Color(0, 204, 204));
		jPanel1.setEnabled(false);
		jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

		jLabel2.setText("\u56fe\u7247");
		jLabel2.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(0, 0, 0)));
		jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				110, 170, 800, 270));

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel5.setText("\u6d3b\u52a8\u4ecb\u7ecd\uff1a");
		jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				110, 460, 100, 30));

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel3.setText("\u6d3b\u52a8\u65f6\u95f4\uff1a");
		jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				110, 610, 100, 30));

		jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel6.setText("\u6d3b\u52a8\u5730\u70b9\uff1a");
		jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				110, 650, 100, 30));

		jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel8.setText("\u6ce8\u610f\u4e8b\u9879\uff1a");
		jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				110, 730, 100, 30));

		jLabel7.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel7.setText("\u6d3b\u52a8\u4eba\u6570\uff1a");
		jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				110, 690, 100, 30));
		jPanel1.add(jTextField3,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 650,
						710, 30));

		jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel11.setText("\u65e5");
		jPanel1.add(jLabel11,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 610, -1,
						-1));

		jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel10.setText("\u6708");
		jPanel1.add(jLabel10,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 610, -1,
						-1));

		jComboBox1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboBox1ActionPerformed(evt);
			}
		});
		jPanel1.add(jComboBox1,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 610, -1,
						-1));

		jComboBox2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jComboBox2.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jPanel1.add(jComboBox2,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 610, -1,
						-1));

		jComboBox3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jPanel1.add(jComboBox3,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 610, -1,
						-1));

		jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel9.setText("\u5e74");
		jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				280, 610, -1, -1));

		jComboBox4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jComboBox4.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jPanel1.add(jComboBox4,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 690, -1,
						-1));

		jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel12.setText("\u4eba~");
		jPanel1.add(jLabel12,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 690, -1,
						-1));

		jComboBox5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jPanel1.add(jComboBox5,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 690, -1,
						-1));

		jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel13.setText("\u4eba");
		jPanel1.add(jLabel13,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 690, -1,
						-1));

		jTextField2.setBackground(new java.awt.Color(0, 204, 204));
		jTextField2.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 36));
		jTextField2.setForeground(new java.awt.Color(255, 204, 0));
		jTextField2.setText("\u7f16\u8f91\u6d3b\u52a8");
		jTextField2.setBorder(null);
		jPanel1.add(jTextField2,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1,
						-1));

		jTextArea1.setColumns(20);
		jTextArea1.setRows(5);
		jScrollPane4.setViewportView(jTextArea1);

		jPanel1.add(jScrollPane4,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 460,
						710, 140));

		jTextArea2.setColumns(20);
		jTextArea2.setRows(5);
		jScrollPane5.setViewportView(jTextArea2);

		jPanel1.add(jScrollPane5,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 730,
						710, 110));

		jButton10.setBackground(new java.awt.Color(255, 204, 0));
		jButton10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton10.setText("\u786e\u8ba4\u7f16\u8f91");
		jButton10.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(255, 255, 255)));
		jButton10.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton10ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton10,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 860,
						100, 50));

		jTextField4.setBackground(new java.awt.Color(0, 204, 204));
		jTextField4.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24));
		jTextField4.setForeground(new java.awt.Color(255, 204, 0));
		jTextField4.setText("\u6d3b\u52a8\u540d\u79f0");
		jTextField4.setBorder(null);
		jPanel1.add(jTextField4,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, -1,
						-1));

		jScrollPane3.setViewportView(jPanel1);

		getContentPane().add(
				jScrollPane3,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 1030,
						600));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		new Blacklist().setVisible(true);
	}

	private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {
		int n = JOptionPane.showConfirmDialog(null, "ȷ�ϱ༭?", "��ʾ",
				JOptionPane.YES_NO_OPTION);
		if (n == 0) {
			JOptionPane.showMessageDialog(null, "�༭�ɹ�");
			new MyRelese().setVisible(true);
		} else {
			new Edit().setVisible(true);
		}
	}

	private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
	}

	private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
		new Edit().setVisible(true);
	}

	private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
		new MyRelese().setVisible(true);
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new Index().setVisible(true);
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Edit().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton9;
	private javax.swing.JComboBox jComboBox1;
	private javax.swing.JComboBox jComboBox2;
	private javax.swing.JComboBox jComboBox3;
	private javax.swing.JComboBox jComboBox4;
	private javax.swing.JComboBox jComboBox5;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JScrollPane jScrollPane4;
	private javax.swing.JScrollPane jScrollPane5;
	private javax.swing.JTextArea jTextArea1;
	private javax.swing.JTextArea jTextArea2;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;
	// End of variables declaration//GEN-END:variables

}