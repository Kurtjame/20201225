/*
 * Register.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import module.Activity;
import module.User;
import org.netbeans.lib.awtextra.AbsoluteConstraints;
import org.netbeans.lib.awtextra.AbsoluteLayout;

import javax.swing.*;
import java.sql.SQLException;

/**
 *
 * @author  __USER__
 */
public class ActivityInfo extends JFrame {

	/** Creates new form Register */
	public ActivityInfo() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">

	private void initComponents() {

		jButton1 = new JButton();
		jLabel4 = new JLabel();
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);


		jPanel1 = new JPanel();
		jPanel1.setBackground(new java.awt.Color(0, 204, 204));
		jPanel1.setLayout(new AbsoluteLayout());




		jLabel4.setFont(new java.awt.Font("����", 1, 72));
		jLabel4.setText("����");
		jPanel1.add(jLabel4, new AbsoluteConstraints(
				200, 100, -1, -1));



		jLabel1 = new JLabel();
		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel1.setText("actname");
		jPanel1.add(jLabel1, new AbsoluteConstraints(
				200, 240, -1, -1));

		jTextField1 = new JTextField();
		jTextField1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});
		jPanel1.add(jTextField1,
				new AbsoluteConstraints(390, 240,
						500, 50));




		jLabel12 = new JLabel();
		jTextField12 = new JTextField();
		jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel12.setText("acttime");
		jPanel1.add(jLabel12, new AbsoluteConstraints(
				200, 310, -1, -1));

		jTextField12.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField12,
				new AbsoluteConstraints(390, 310,
						500, 50));



		jLabel13 = new JLabel();
		jTextField13 = new JTextField();
		jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel13.setText("actstyle");
		jPanel1.add(jLabel13, new AbsoluteConstraints(
				200, 380, -1, -1));

		jTextField13.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField13,
				new AbsoluteConstraints(390, 380,
						500, 50));


		jLabel11 = new JLabel();
		jTextField11 = new JTextField();
		jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel11.setText("endtime");
		jPanel1.add(jLabel11, new AbsoluteConstraints(
				200, 450, -1, -1));

		jTextField11.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField11,
				new AbsoluteConstraints(390, 450,
						500, 50));



		jLabel14 = new JLabel();
		jTextField14 = new JTextField();
		jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel14.setText("astatus");
		jPanel1.add(jLabel14, new AbsoluteConstraints(
				200, 520, -1, -1));

		jTextField14.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jTextField14,
				new AbsoluteConstraints(390, 520,
						500, 50));






























		jButton1.setBackground(new java.awt.Color(255, 204, 51));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton1.setText("ȷ��");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton1,
				new AbsoluteConstraints(390, 590,
						500, 50));


		GroupLayout layout = new GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, GroupLayout.PREFERRED_SIZE, 1200,
				GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, GroupLayout.PREFERRED_SIZE, 600,
				GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new Login().setVisible(true);
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		Activity activity=new Activity();

		activity.setActname(this.jTextField1.getText());
		activity.setActtime(this.jTextField1.getText());
		activity.setActstyle(this.jTextField1.getText());
		activity.setEndtime(this.jTextField1.getText());
		activity.setLimitpeople(this.jTextField1.getText());
		activity.setAstatus(this.jTextField1.getText());

		try {
			boolean b=activity.insert(activity);
			if(b){
				JOptionPane.showMessageDialog(null, "�����ɹ�");
			}else {
				JOptionPane.showMessageDialog(null, "����ʧ��");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.dispose();
	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new ActivityInfo().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private JTextField jTextField1;
	private JLabel jLabel1;
	private JPanel jPanel1;



	private JButton jButton1;
	private JLabel jLabel4;

	private JLabel jLabel11;
	private JTextField jTextField11;

	private JLabel jLabel12;
	private JTextField jTextField12;
	private JLabel jLabel13;
	private JTextField jTextField13;
	private JLabel jLabel14;
	private JTextField jTextField14;

	// End of variables declaration//GEN-END:variables

}