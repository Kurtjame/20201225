/*
 * Login.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import dao.*;

import util.*;

import module.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import com.sun.security.auth.UserPrincipal;

import util.StringUtil;

import module.Admin;
import module.User;
import module.Usertype;

/**
 *
 * @author  __USER__
 */
public class Login extends javax.swing.JFrame implements ActionListener {

	/** Creates new form Login */
	public Login() {
		initComponents();
		this.setLocationRelativeTo(null);
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		buttonGroup1 = new javax.swing.ButtonGroup();
		jPanel1 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jPasswordField1 = new javax.swing.JPasswordField();
		jButton1 = new javax.swing.JButton();
		jLabel3 = new javax.swing.JLabel();
		jButton2 = new javax.swing.JButton();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jRadioButton1 = new javax.swing.JRadioButton();
		jRadioButton2 = new javax.swing.JRadioButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);

		jPanel1.setBackground(new java.awt.Color(0, 204, 204));
		jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel1.setText("\u8d26\u53f7\uff1a");
		jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				300, 240, -1, -1));

		jTextField1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});
		jPanel1.add(jTextField1,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 240,
						500, 50));

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 36));
		jLabel2.setText("\u5bc6\u7801\uff1a");
		jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				300, 310, -1, -1));

		jPasswordField1.setFont(new java.awt.Font("����", 0, 24));
		jPanel1.add(jPasswordField1,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 310,
						500, 50));

		jButton1.setBackground(new java.awt.Color(255, 204, 51));
		jButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jButton1.setText("\u767b\u5f55");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton1,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 420,
						500, 50));

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel3.setForeground(new java.awt.Color(255, 204, 0));
		jLabel3.setText("\u6ca1\u6709\u8d26\u53f7\uff1f");
		jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				760, 490, -1, -1));

		jButton2.setBackground(new java.awt.Color(0, 204, 204));
		jButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jButton2.setForeground(new java.awt.Color(255, 204, 0));
		jButton2.setText("\u6ce8\u518c");
		jButton2.setBorder(null);
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton2,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 490, -1,
						-1));

		jLabel4.setFont(new java.awt.Font("����", 1, 72));
		jLabel4.setText("\u767b\u5f55\u5bc2\u5bde\u5c31\u6765");
		jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				200, 100, -1, -1));

		jLabel5.setFont(new java.awt.Font("����", 1, 72));
		jLabel5.setForeground(new java.awt.Color(255, 204, 0));
		jLabel5.setText("\u5bc2\u5bde\u5c31\u6765");
		jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(
				349, 100, -1, -1));

		jRadioButton1.setBackground(new java.awt.Color(0, 204, 204));
		jRadioButton1.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jRadioButton1.setText("\u7528\u6237");
		jPanel1.add(jRadioButton1,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 370, -1,
						-1));

		jRadioButton2.setBackground(new java.awt.Color(0, 204, 204));
		jRadioButton2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jRadioButton2.setText("\u7ba1\u7406\u5458");
		jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jRadioButton2ActionPerformed(evt);
			}
		});
		jPanel1.add(jRadioButton2,
				new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 370, -1,
						-1));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1200,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 600,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		new Register().setVisible(true);
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent ae) {
		loginAct(ae);

	}

	/**
	 * ��¼
	 * @param ae
	 */
	private void loginAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		String uname = this.jTextField1.getText().toString();
		String pw = this.jPasswordField1.getText().toString();

		JComboBox usertypeComboBox = new javax.swing.JComboBox();;
		Usertype selectedItem = (Usertype) usertypeComboBox.getSelectedItem();
		if (StringUtil.isEmpty(uname)) {
			JOptionPane.showMessageDialog(this, "�û�������Ϊ�գ�");
			return;
		}
		if (StringUtil.isEmpty(pw)) {
			JOptionPane.showMessageDialog(this, "���벻��Ϊ�գ�");
			return;
		}

		if (this.jRadioButton1.isSelected()) {

			User u = new User();
			String id=u.login(uname, pw);
			if (!"".equals(id)) {
				new Index(id).setVisible(true);
				this.dispose();
			} else {
				JOptionPane.showMessageDialog(this, "��½ʧ��");
			}

		} else if (this.jRadioButton2.isSelected()) {

			Admin a = new Admin(uname,0, pw);
			try {
				if (a.login(uname, pw)) {
					new Index("999").setVisible(true);
					this.dispose();
				} else {
					JOptionPane.showMessageDialog(this, "��½ʧ��");
				}
			} catch (SQLException e) {
				// TODO: handle exception
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "��½ʧ��");

			}
		}

	}

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Login().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.ButtonGroup buttonGroup1;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPasswordField jPasswordField1;
	private javax.swing.JRadioButton jRadioButton1;
	private javax.swing.JRadioButton jRadioButton2;
	private javax.swing.JTextField jTextField1;

	// End of variables declaration//GEN-END:variables
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

}