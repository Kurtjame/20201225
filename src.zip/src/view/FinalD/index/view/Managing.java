/*
 * Managing.java
 *
 * Created on __DATE__, __TIME__
 */

package FinalD.index.view;

import module.User;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

import org.netbeans.lib.awtextra.AbsoluteLayout;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 *
 * @author  __USER__
 */
public class Managing extends JFrame {

	/** Creates new form Managing */
	public Managing() {
		this.id="";
		initComponents();
		this.setLocationRelativeTo(null);
	}
	public Managing(String id) {
		this.id=id;
		initComponents();
		this.setLocationRelativeTo(null);
	}


	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		User user=new User();
		if(!"999".equals(this.id) ){
			List list=User.listById(this.id);
			user= (User) list.get(0);

		}

		jPanel2 = new JPanel();

		jButton9 = new JButton();
		jScrollPane1 = new JScrollPane();
		jPanel1 = new JPanel();
		jLabel4 = new JLabel();
		jLabel5 = new JLabel();
		jLabel3 = new JLabel();
		jLabel6 = new JLabel();
		jLabel8 = new JLabel();
		jLabel7 = new JLabel();
		jButton8 = new JButton();
		jLabel9 = new JLabel();
		jLabel10 = new JLabel();
		jLabel12 = new JLabel();
		jLabel14 = new JLabel();
		jComboBox3 = new JComboBox();
		jLabel13 = new JLabel();
		jComboBox2 = new JComboBox();
		jLabel11 = new JLabel();
		jComboBox1 = new JComboBox();
		jComboBox4 = new JComboBox();
		jTextField1 = new JTextField();
		jTextField2 = new JTextField();
		jTextField3 = new JTextField();
		jTextField4 = new JTextField();
		jTextField5 = new JTextField();

		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);
		getContentPane().setLayout(
				new AbsoluteLayout());

		jPanel2.setBackground(new Color(255, 204, 102));
		jPanel2.setLayout(new AbsoluteLayout());



		jButton9.setBackground(new Color(0, 204, 204));
		jButton9.setFont(new Font("Microsoft YaHei UI", 1, 24));
		jButton9.setForeground(new Color(255, 204, 0));
		jButton9.setText("<back");
		jButton9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton9ActionPerformed(evt);
			}
		});
		jPanel2.add(jButton9,
				new AbsoluteConstraints(0, 20, 170,
						50));



		getContentPane().add(
				jPanel2,
				new AbsoluteConstraints(0, 0, 170,
						600));

		jPanel1.setBackground(new Color(0, 204, 204));
		jPanel1.setLayout(new AbsoluteLayout());

		jLabel4.setFont(new Font("Microsoft YaHei UI", 1, 28));
		jLabel4.setForeground(new Color(255, 204, 0));
		jLabel4.setText("���¸�����Ϣ");
		jPanel1.add(jLabel4, new AbsoluteConstraints(
				90, 30, -1, -1));

		jLabel5.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel5.setText("��ʵ������");
		jPanel1.add(jLabel5, new AbsoluteConstraints(
				120, 80, 100, 30));

		jLabel3.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel3.setText("��       ��");
		jPanel1.add(jLabel3, new AbsoluteConstraints(
				120, 120, -1, 30));

		jLabel6.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel6.setText("��       �գ�");
		jPanel1.add(jLabel6, new AbsoluteConstraints(
				120, 160, 100, 30));

		jLabel8.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel8.setText("��Ȥ���ã�");
		jPanel1.add(jLabel8, new AbsoluteConstraints(
				120, 200, 100, 30));

		jLabel7.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel7.setText("��ϵ��ʽ��");
		jPanel1.add(jLabel7, new AbsoluteConstraints(
				120, 240, 100, 30));

		jButton8.setBackground(new Color(255, 204, 0));
		jButton8.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jButton8.setText("ȷ�ϸ�����Ϣ");
		jButton8.setBorder(BorderFactory
				.createLineBorder(new Color(255, 255, 255)));
		jButton8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jButton8ActionPerformed(evt);
			}
		});
		jPanel1.add(jButton8,
				new AbsoluteConstraints(720, 500,
						200, 50));

		jLabel9.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel9.setText("\u6240\u5728\u5730\u533a\uff1a");
		jPanel1.add(jLabel9, new AbsoluteConstraints(
				120, 280, 100, 30));

		jLabel10.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel10.setText("\u4e2a\u4eba\u8bf4\u660e\uff1a");
		jPanel1.add(jLabel10,
				new AbsoluteConstraints(120, 320,
						100, 30));

		jLabel12.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel12.setText("\u4fe1\u8a89\u7b49\u7ea7\uff1a");
		jPanel1.add(jLabel12,
				new AbsoluteConstraints(120, 400,
						100, 30));

		jLabel14.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel14.setText("\u65e5");
		jPanel1.add(jLabel14,
				new AbsoluteConstraints(480, 160, -1,
						-1));

		jComboBox3.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jComboBox3.setModel(new DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jPanel1.add(jComboBox3,
				new AbsoluteConstraints(420, 160, -1,
						-1));

		jLabel13.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel13.setText("\u6708");
		jPanel1.add(jLabel13,
				new AbsoluteConstraints(390, 160, -1,
						-1));

		jComboBox2.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jComboBox2.setModel(new DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jPanel1.add(jComboBox2,
				new AbsoluteConstraints(330, 160, -1,
						30));

		jLabel11.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jLabel11.setText("\u5e74");
		jPanel1.add(jLabel11,
				new AbsoluteConstraints(300, 160, -1,
						-1));

		jComboBox1.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jComboBox1.setModel(new DefaultComboBoxModel(new String[] {
				"Item 1", "Item 2", "Item 3", "Item 4" }));
		jComboBox1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jComboBox1ActionPerformed(evt);
			}
		});
		jPanel1.add(jComboBox1,
				new AbsoluteConstraints(220, 160, -1,
						30));

		jComboBox4.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jComboBox4.setModel(new DefaultComboBoxModel(new String[] {
				"��", "Ů" }));
		jPanel1.add(jComboBox4,
				new AbsoluteConstraints(220, 120, 90,
						-1));

		jTextField1.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jPanel1.add(jTextField1,
				new AbsoluteConstraints(220, 80, 100,
						30));

		jTextField2.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jTextField2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				jTextField2ActionPerformed(evt);
			}
		});
		jPanel1.add(jTextField2,
				new AbsoluteConstraints(220, 200,
						700, 30));

		jTextField3.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jPanel1.add(jTextField3,
				new AbsoluteConstraints(220, 280,
						700, 30));

		jTextField4.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jPanel1.add(jTextField4,
				new AbsoluteConstraints(220, 240,
						700, 30));

		jTextField5.setFont(new Font("Microsoft YaHei UI", 0, 18));
		jPanel1.add(jTextField5,
				new AbsoluteConstraints(220, 320,
						700, 60));

		jScrollPane1.setViewportView(jPanel1);

		getContentPane().add(
				jScrollPane1,
				new AbsoluteConstraints(170, 0, 1030,
						600));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton7ActionPerformed(ActionEvent evt) {
		new Blacklist().setVisible(true);
	}

	private void jTextField2ActionPerformed(ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jComboBox1ActionPerformed(ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton8ActionPerformed(ActionEvent evt) {
		User user=new User();
		user.setUid(this.id);
		user.setUname(jTextField1.getText());
		user.setUhobby(jTextField2.getText());
		user.setUlct(jTextField3.getText());
		user.setUgd(jTextField4.getText());
		user.setUcontact(jTextField5.getText());
		boolean b=User.update(user);
		if(b){
			JOptionPane.showMessageDialog(null, "���³ɹ�");
		}else {
			JOptionPane.showMessageDialog(null, "����ʧ��");
		}
		this.dispose();
		new Manage().setVisible(true);
	}

	private void jButton9ActionPerformed(ActionEvent evt) {
		this.dispose();
	}

	private void jButton6ActionPerformed(ActionEvent evt) {
		new Relese().setVisible(true);
	}

	private void jButton5ActionPerformed(ActionEvent evt) {
		new Manage().setVisible(true);
	}

	private void jButton4ActionPerformed(ActionEvent evt) {
		new Order().setVisible(true);
	}

	private void jButton3ActionPerformed(ActionEvent evt) {
		new MyRelese().setVisible(true);
	}

	private void jButton1ActionPerformed(ActionEvent evt) {
		new Index().setVisible(true);
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Managing().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify

	private JButton jButton8;
	private JButton jButton9;
	private JComboBox jComboBox1;
	private JComboBox jComboBox2;
	private JComboBox jComboBox3;
	private JComboBox jComboBox4;
	private JLabel jLabel10;
	private JLabel jLabel11;
	private JLabel jLabel12;
	private JLabel jLabel13;
	private JLabel jLabel14;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JLabel jLabel6;
	private JLabel jLabel7;
	private JLabel jLabel8;
	private JLabel jLabel9;
	private JPanel jPanel1;
	private JPanel jPanel2;
	private JScrollPane jScrollPane1;
	private JTextField jTextField1;
	private JTextField jTextField2;
	private JTextField jTextField3;
	private JTextField jTextField4;
	private JTextField jTextField5;
	// End of variables declaration//GEN-END:variables
	private String id;
}